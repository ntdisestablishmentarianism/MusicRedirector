package com.musicredirector

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/**
 * Settings screen where the user configures their preferred music app
 * and toggles redirection on/off.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    // Views
    private lateinit var masterToggle: Switch
    private lateinit var statusIndicator: View
    private lateinit var statusText: TextView
    private lateinit var appSpinner: Spinner
    private lateinit var bypassSameAppToggle: Switch
    private lateinit var selectedAppStatus: TextView
    private lateinit var openDefaultAppsButton: Button
    private lateinit var testLinkButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        bindViews()
        setupAppSpinner()
        setupListeners()
        updateUI()
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun bindViews() {
        masterToggle        = findViewById(R.id.masterToggle)
        statusIndicator     = findViewById(R.id.statusIndicator)
        statusText          = findViewById(R.id.statusText)
        appSpinner          = findViewById(R.id.appSpinner)
        bypassSameAppToggle = findViewById(R.id.bypassSameAppToggle)
        selectedAppStatus   = findViewById(R.id.selectedAppStatus)
        openDefaultAppsButton = findViewById(R.id.openDefaultAppsButton)
        testLinkButton      = findViewById(R.id.testLinkButton)
    }

    private fun setupAppSpinner() {
        val apps = MusicApp.values()
        val names = apps.map { it.displayName }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        appSpinner.adapter = adapter
        appSpinner.setSelection(apps.indexOf(prefs.targetApp))

        appSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                prefs.targetApp = apps[pos]
                updateSelectedAppStatus(apps[pos])
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun setupListeners() {
        masterToggle.setOnCheckedChangeListener { _, checked ->
            prefs.redirectEnabled = checked
            updateStatusBadge(checked)
        }

        bypassSameAppToggle.setOnCheckedChangeListener { _, checked ->
            prefs.bypassSameApp = checked
        }

        // Opens Android's Default Apps settings so user can verify link handling
        openDefaultAppsButton.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                })
            }
        }

        // Fires a test Spotify link that will be caught and redirected
        testLinkButton.setOnClickListener {
            val testIntent = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://open.spotify.com/track/4iV5W9uYEdYUVa79Axb7Rh")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(testIntent)
        }
    }

    private fun updateUI() {
        masterToggle.isChecked        = prefs.redirectEnabled
        bypassSameAppToggle.isChecked = prefs.bypassSameApp
        updateStatusBadge(prefs.redirectEnabled)
        updateSelectedAppStatus(prefs.targetApp)
    }

    private fun updateStatusBadge(enabled: Boolean) {
        if (enabled) {
            statusIndicator.setBackgroundResource(R.drawable.indicator_active)
            statusText.text = "Redirecting • Active"
        } else {
            statusIndicator.setBackgroundResource(R.drawable.indicator_inactive)
            statusText.text = "Redirecting • Paused"
        }
    }

    private fun updateSelectedAppStatus(app: MusicApp) {
        val installed = isAppInstalled(app.packageName)
        selectedAppStatus.text = if (installed) {
            "✓ ${app.displayName} is installed"
        } else {
            "⚠ ${app.displayName} is not installed — links will open in browser"
        }
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }
}
