package com.musicredirector

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/**
 * ──────────────────────────────────────────────────────────────
 *  RedirectActivity
 * ──────────────────────────────────────────────────────────────
 *  This is the core of MusicRedirector.
 *
 *  It is declared with a transparent theme so it's invisible to
 *  the user. When a music link is clicked anywhere on the device,
 *  Android routes it here (via the intent filters in the manifest).
 *
 *  Flow:
 *  1. Receive the incoming URL intent
 *  2. Check if redirection is enabled
 *  3. Detect which platform the link is from
 *  4. If it's already the target app → open directly
 *  5. Otherwise → call Odesli API to resolve the link
 *  6. Build and fire an Intent for the target app
 *  7. Finish (the transparent activity disappears)
 * ──────────────────────────────────────────────────────────────
 */
class RedirectActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIntent(it) }
    }

    private fun handleIntent(intent: Intent) {
        val incomingUrl = intent.data?.toString()

        if (incomingUrl == null) {
            finish()
            return
        }

        // ── Master toggle ──────────────────────────────────────
        if (!prefs.redirectEnabled) {
            openUrlDirectly(incomingUrl)
            finish()
            return
        }

        val targetApp  = prefs.targetApp
        val sourceApp  = MusicApp.detectFromUrl(incomingUrl)

        // ── Same app bypass ────────────────────────────────────
        if (prefs.bypassSameApp && sourceApp == targetApp) {
            openUrlDirectly(incomingUrl)
            finish()
            return
        }

        // ── Redirect via Odesli ────────────────────────────────
        lifecycleScope.launch {
            val result = OdesliService.resolve(incomingUrl)

            if (result == null) {
                // API failed — fall back to original URL
                showToast("Couldn't resolve link, opening original…")
                openUrlDirectly(incomingUrl)
            } else {
                val redirectUrl = result.getLinkFor(targetApp)

                if (redirectUrl.isNullOrEmpty()) {
                    showToast("${targetApp.displayName} link not found, opening original…")
                    openUrlDirectly(incomingUrl)
                } else {
                    val songInfo = buildString {
                        if (!result.title.isNullOrEmpty()) append(result.title)
                        if (!result.artist.isNullOrEmpty()) {
                            if (isNotEmpty()) append(" · ")
                            append(result.artist)
                        }
                    }
                    if (songInfo.isNotEmpty()) {
                        showToast("Opening in ${targetApp.displayName}: $songInfo")
                    }
                    openInTargetApp(redirectUrl, targetApp)
                }
            }
            finish()
        }
    }

    /**
     * Opens the resolved URL in the target music app.
     * Tries the native app URI first; if the app isn't installed,
     * falls back to a browser web URL.
     */
    private fun openInTargetApp(url: String, targetApp: MusicApp) {
        val uri = Uri.parse(url)

        // Try native app intent first
        val appIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage(targetApp.packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (isIntentResolvable(appIntent)) {
            startActivity(appIntent)
            return
        }

        // App not installed — try generic VIEW (browser / other handler)
        val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            startActivity(fallbackIntent)
        } catch (e: Exception) {
            showToast("Could not open link")
        }
    }

    /** Open URL without redirection (pass-through) */
    private fun openUrlDirectly(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // Exclude ourselves to avoid redirect loop!
                addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
            // Remove our package so we don't intercept our own fallback
            intent.setPackage(null)
            startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: Exception) {
            showToast("Could not open link")
        }
    }

    private fun isIntentResolvable(intent: Intent): Boolean {
        return packageManager
            .queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .isNotEmpty()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
