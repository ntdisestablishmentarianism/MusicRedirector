package com.musicredirector

/**
 * Represents all supported music platforms.
 * Each entry maps to the Odesli API platform key and holds deep link templates.
 */
enum class MusicApp(
    val displayName: String,
    val odesliKey: String,          // Key in Odesli API linksByPlatform response
    val packageName: String,         // Android package name to check if installed
    val nativeScheme: String,        // Native URI scheme for direct app open
    val webFallbackBase: String      // Web URL fallback if app not installed
) {
    SPOTIFY(
        displayName    = "Spotify",
        odesliKey      = "spotify",
        packageName    = "com.spotify.music",
        nativeScheme   = "spotify",
        webFallbackBase = "https://open.spotify.com"
    ),
    YOUTUBE_MUSIC(
        displayName    = "YouTube Music",
        odesliKey      = "youtubeMusic",
        packageName    = "com.google.android.apps.youtube.music",
        nativeScheme   = "https",
        webFallbackBase = "https://music.youtube.com"
    ),
    APPLE_MUSIC(
        displayName    = "Apple Music",
        odesliKey      = "appleMusic",
        packageName    = "com.apple.android.music",
        nativeScheme   = "https",
        webFallbackBase = "https://music.apple.com"
    ),
    SOUNDCLOUD(
        displayName    = "SoundCloud",
        odesliKey      = "soundcloud",
        packageName    = "com.soundcloud.android",
        nativeScheme   = "soundcloud",
        webFallbackBase = "https://soundcloud.com"
    ),
    TIDAL(
        displayName    = "Tidal",
        odesliKey      = "tidal",
        packageName    = "com.aspiro.tidal",
        nativeScheme   = "tidal",
        webFallbackBase = "https://tidal.com"
    ),
    DEEZER(
        displayName    = "Deezer",
        odesliKey      = "deezer",
        packageName    = "deezer.android.app",
        nativeScheme   = "deezer",
        webFallbackBase = "https://www.deezer.com"
    ),
    AMAZON_MUSIC(
        displayName    = "Amazon Music",
        odesliKey      = "amazonMusic",
        packageName    = "com.amazon.mp3",
        nativeScheme   = "https",
        webFallbackBase = "https://music.amazon.com"
    ),
    PANDORA(
        displayName    = "Pandora",
        odesliKey      = "pandora",
        packageName    = "com.pandora.android",
        nativeScheme   = "pandora",
        webFallbackBase = "https://www.pandora.com"
    );

    companion object {
        fun fromKey(key: String): MusicApp? = values().find { it.odesliKey == key }

        /** Detect which platform a URL belongs to */
        fun detectFromUrl(url: String): MusicApp? = when {
            url.contains("open.spotify.com") || url.startsWith("spotify://")
                -> SPOTIFY
            url.contains("music.youtube.com")
                -> YOUTUBE_MUSIC
            url.contains("music.apple.com") || url.contains("itunes.apple.com")
                -> APPLE_MUSIC
            url.contains("soundcloud.com") || url.startsWith("soundcloud://")
                -> SOUNDCLOUD
            url.contains("tidal.com") || url.startsWith("tidal://")
                -> TIDAL
            url.contains("deezer.com") || url.startsWith("deezer://")
                -> DEEZER
            url.contains("music.amazon.com")
                -> AMAZON_MUSIC
            url.contains("pandora.com") || url.startsWith("pandora://")
                -> PANDORA
            else -> null
        }
    }
}
