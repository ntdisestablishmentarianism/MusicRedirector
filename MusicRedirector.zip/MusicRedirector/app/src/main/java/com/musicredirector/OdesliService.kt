package com.musicredirector

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Wraps the Odesli (song.link) API to convert any music URL into
 * equivalent links across all supported platforms.
 *
 * API docs: https://odesli.co
 * Free tier: 10 requests/min, no API key required.
 */
object OdesliService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private const val API_BASE = "https://api.song.link/v1-alpha.1/links"

    /**
     * Resolves a music URL and returns a map of platform -> link info.
     *
     * @param url Any music platform URL (Spotify, YouTube Music, Apple Music, etc.)
     * @return [OdesliResult] with per-platform links, or null on failure
     */
    suspend fun resolve(url: String): OdesliResult? = withContext(Dispatchers.IO) {
        try {
            val encodedUrl = java.net.URLEncoder.encode(url, "UTF-8")
            val apiUrl = "$API_BASE?url=$encodedUrl&userCountry=US"

            val request = Request.Builder()
                .url(apiUrl)
                .header("Accept", "application/json")
                .build()

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext null
            }

            val body = response.body?.string() ?: return@withContext null
            parseResponse(body)

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun parseResponse(json: String): OdesliResult? {
        return try {
            val root = JSONObject(json)
            val linksByPlatform = root.optJSONObject("linksByPlatform") ?: return null

            val platformLinks = mutableMapOf<String, PlatformLink>()

            // Iterate all platform keys in the response
            linksByPlatform.keys().forEach { platformKey ->
                val platformObj = linksByPlatform.getJSONObject(platformKey)
                platformLinks[platformKey] = PlatformLink(
                    url = platformObj.optString("url"),
                    nativeAppUriMobile = platformObj.optString("nativeAppUriMobile"),
                    entityUniqueId = platformObj.optString("entityUniqueId")
                )
            }

            // Extract song metadata from entitiesByUniqueId
            val entitiesObj = root.optJSONObject("entitiesByUniqueId")
            var title: String? = null
            var artist: String? = null
            var thumbnailUrl: String? = null

            if (entitiesObj != null) {
                val firstEntityKey = entitiesObj.keys().asSequence().firstOrNull()
                if (firstEntityKey != null) {
                    val entity = entitiesObj.getJSONObject(firstEntityKey)
                    title = entity.optString("title").takeIf { it.isNotEmpty() }
                    artist = entity.optString("artistName").takeIf { it.isNotEmpty() }
                    thumbnailUrl = entity.optString("thumbnailUrl").takeIf { it.isNotEmpty() }
                }
            }

            OdesliResult(
                platformLinks = platformLinks,
                title = title,
                artist = artist,
                thumbnailUrl = thumbnailUrl
            )

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

data class OdesliResult(
    val platformLinks: Map<String, PlatformLink>,
    val title: String?,
    val artist: String?,
    val thumbnailUrl: String?
) {
    /** Get the link for a specific target app, preferring native URI. */
    fun getLinkFor(app: MusicApp): String? {
        val platformLink = platformLinks[app.odesliKey] ?: return null
        // Prefer native app URI, fall back to web URL
        return platformLink.nativeAppUriMobile
            .takeIf { it.isNotEmpty() }
            ?: platformLink.url.takeIf { it.isNotEmpty() }
    }
}

data class PlatformLink(
    val url: String,
    val nativeAppUriMobile: String,
    val entityUniqueId: String
)
