package com.musicredirector

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages persistent user preferences for MusicRedirector.
 */
class Prefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("music_redirector_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TARGET_APP = "target_app"
        private const val KEY_ENABLED    = "redirect_enabled"
        private const val KEY_BYPASS_SAME = "bypass_same_app"
    }

    /** The music app to redirect all links to. Default: Spotify */
    var targetApp: MusicApp
        get() = MusicApp.valueOf(prefs.getString(KEY_TARGET_APP, MusicApp.SPOTIFY.name)!!)
        set(value) = prefs.edit().putString(KEY_TARGET_APP, value.name).apply()

    /** Master toggle — when off, links open normally */
    var redirectEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    /**
     * If true, links that already match the target app are opened directly
     * without going through the redirect (avoids unnecessary API calls).
     */
    var bypassSameApp: Boolean
        get() = prefs.getBoolean(KEY_BYPASS_SAME, true)
        set(value) = prefs.edit().putBoolean(KEY_BYPASS_SAME, value).apply()
}
